package com.bezkoder.spring.datajpa.model;

public @interface Builderpublic {

}
