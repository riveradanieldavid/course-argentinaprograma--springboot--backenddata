package com.bezkoder.spring.datajpa.service;

public class fileDBRepository {

}
